"""
Convenience wrapper: runs both gpt5_inference.py and gemini3_inference.py
against the same prompts.txt, so all 40 outputs (20 prompts x 2 models)
land in generated_samples/.

Usage:
    python run_all.py
"""

import subprocess
import sys

SCRIPTS = ["gpt5_inference.py", "gemini3_inference.py"]

for script in SCRIPTS:
    print(f"\n=== Running {script} ===")
    result = subprocess.run([sys.executable, script])
    if result.returncode != 0:
        print(f"[warning] {script} exited with code {result.returncode}")
